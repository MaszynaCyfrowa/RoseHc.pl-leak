package pl.rosehc.achievements.achievement;

public enum AchievementBoostType {

  KILL_POINTS, KILL_AND_DEATH_POINTS,
  DROP_CHANCE
}
